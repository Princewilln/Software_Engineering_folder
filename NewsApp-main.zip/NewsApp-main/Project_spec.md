# **NewsTrail**

## Table of Contents

1. [App Overview](#App-Overview)
1. [Product Spec](#Product-Spec)
1. [Wireframes](#Wireframes)
1. [Build Notes](#Build-Notes)

## App Overview

### Description 

**This application will provide the news going on in the United States and update it every 1 hour using the api.**

### App Evaluation

<!-- Evaluation of your app across the following attributes -->

- **Category: It's an entertainment category like movies, politics, general affairs etc.**
- **Mobile: People would prefer more of mobile application rather than website because of the better quality exprience  user can get in mobile app rather than website.**
- **Story: News application is kinda growing industry and mobile application is one of the biggest market in tech. Combining it would create a great profit out of both the industry. It is said that news industry to grow to 36.32 million USD by 2028. Imagining mobile application of news can create a lot more than what is expected as the mobile industry right now is 206.85 billion USD which is showing 13.8% growth rate in next decade.**
- **Market: News Indutry has 13.66 million USD right now and mobile application has 206.85 billion USD currently. While the combined market in 2021 was 1.18 billion USD.**
- **Habit: News is the daily requirement of each person. So, it's on the UI that how better format and simple and classy it looks. Better the UI better is the addiction.**
- **Scope: It has to a be great UI app with features being user friendly. And the basic version is a lot interesting to build because it would give an idea how better and friendly the interface can be.**

## Product Spec

### 1. User Features (Required and Optional)

Required Features:

- **User can search for headlines.**
- **User can search for there favorite genre.**
- **User can search for news of perticular state or place.**

Stretch Features:

- **User can like the news and comment downs his opinion.**
- **User can share the news with known ones.**

### 2. Chosen API(s)

- **list first API endpoint here**
  - **https://newsapi.org/v2/top-headlines?sources=bbc-news&apiKey=API_KEY**
  - **https://newsapi.org/v2/top-headlines?country=us&apiKey=API_KEY**
- ...

### 3. User Interaction

Required Feature

- **list first user action here**
  - => **Will show multiple news on the app user needs to tap on the news which will give the broad news on info.**
  
- **list second user action here**
  - => **Can also search on the topic and news related to it will come to feed.**
  

## Wireframes

<!-- Add picture of your hand sketched wireframes in this section -->
<img src="https://github.com/Group28-Project/NewsApp/blob/main/Wireframe.png" width=600>

### [BONUS] Digital Wireframes & Mockups

### [BONUS] Interactive Prototype

## Build Notes

Here's a place for any other notes on the app, it's creation 
process, or what you learned this unit!  

For Milestone 2, include **2+ Videos/GIFs** of the build process here!

## License

Copyright **2023** **Jay Patel**

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
