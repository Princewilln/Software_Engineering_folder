Mobile App Dev - App Brainstorming Example
===

## Favorite Existing Apps - List
1. Instagram
2. Spotify
3. Tesla
4. WhatsApp
5. Twitter
6. DoorDash

## Favorite Existing Apps - Categorize and Evaluate

### Instagram
   - **Category:** Photo & Video / Social 
   - **Mobile:** Website is view only, uses camera, mobile first experience.
   - **Story:** Allows users to share their lives in pictures and enhance their content with filters
   - **Market:** Anyone that takes pictures could enjoy this app. Ability to follow and hashtag based on interests and categories allows users with unique interests to engage with relevant content.
   - **Habit:** Users can post throughout the day many times. Features like "Stories" encourage more candid posting as well. Users can explore endless pictures in any category imaginable whenever they want. Very habbit forming!
   - **Scope:** Instagram started out extremely narrow focused, just posting pics and viewing feeds. Has expanded to a somewhat larger scope including "Instagram Stories" (a la SnapChat) and messenger features. 

### Spotify
   - **Category:** Music 
   - **Mobile:** Website is view and add by owner.
   - **Story:** Allows users to listen and share their favorite songs with friends.
   - **Market:** Anyone with this app can have fun listening to the songs. Usage is increasing day by day.
   - **Habit:** Songs are one of the most required thing this days while travelling or driving cars. 
   - **Scope:** This app has great scope as we can add broadcast and many audio voices to it. 

## New App Ideas - List
1. UpdateURSelf
   - It's a news applications which allows a person to be updated with the facts going on around them.
2. BookFinder
   - This application allows a person in library to get the location of the book also the status related to it. 
3. GetARoom
   - Helps you to book a room in a hotel with the best price
4. RentHouse
   - This place helps you book a place under a lease with sometime frame.
5. ReminderOClock
   - Helps you remind the important things which you have deadline for.
6. QNA
   - A application which uses the api of the ChatGPT ot any other GPT to provide the answer to the question from the user.

## Top 3 New App Ideas
1. News
2. BookFinder
3. GetARoom

## New App Ideas - Evaluate and Categorize
1. UpdateURSelf
   - **Description**: It's a news applications which allows a person to be updated with the facts going on around them.
   - **Category:** News and Entertainment
   - **Mobile:** Mobile is require to access the application and go on the topic of the interest like international news, finance news, etc.
   - **Story:** Provides you the info using the api of the news application.
   - **Market:** MultiMillion dollar international market as it is used by every person this days on mobile phone.
   - **Habit:** People like to be updated with news going around them so it can be a requirment for every peron in morning.
   - **Scope:** This can be configured more using GoogleNews api which can make is work on larger scale. 



