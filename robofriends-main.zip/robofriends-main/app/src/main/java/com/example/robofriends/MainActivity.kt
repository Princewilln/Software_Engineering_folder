package com.example.robofriends

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import okhttp3.Headers

//https://robohash.org/${id}?size=200x200
//https://jsonplaceholder.typicode.com/users
class MainActivity : AppCompatActivity() {
    private lateinit var robotsList: MutableList<Robot>
    private lateinit var robotsRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        robotsRecyclerView = findViewById<RecyclerView>(R.id.robots_recycler_view)
        robotsList = mutableListOf<Robot>()

        getRobotsData()
    }

    private fun getRobotsData() {
        val client = AsyncHttpClient()

        client["https://jsonplaceholder.typicode.com/users", object :
            JsonHttpResponseHandler() {
            override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                val robotsArray = json.jsonArray;
                for(i in 0 until robotsArray.length()) {
                    val robotObject = robotsArray.getJSONObject(i)
                    val id = robotObject.getString("username")
                    val name = robotObject.getString("name")
                    val email = robotObject.getString("email")
                    val url = "https://robohash.org/$id?size=200x200"
                    Log.d("Robot $i", Robot(id, name, email, url).toString())
                    robotsList.add(Robot(id, name, email, url))
                }

                val robotAdapter = RobotAdapter(robotsList)
                robotsRecyclerView.adapter = robotAdapter
                //catsRecyclerView.layoutManager = LinearLayoutManager(this@MainActivity)
                //catsRecyclerView.addItemDecoration(DividerItemDecoration(this@MainActivity, LinearLayoutManager.VERTICAL))
                robotsRecyclerView.layoutManager = GridLayoutManager(this@MainActivity, 2)
                robotsRecyclerView.addItemDecoration(DividerItemDecoration(this@MainActivity, GridLayoutManager.VERTICAL))
            }

            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                errorResponse: String,
                t: Throwable?
            ) {
                // called when response HTTP status is "4XX" (eg. 401, 403, 404)
                Log.e("An error occurred", errorResponse)
            }
        }]
    }
}