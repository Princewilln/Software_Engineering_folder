package com.example.robofriends

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

data class Robot(
    val id: String,
    val name: String,
    val email: String,
    val url: String
)

class RobotAdapter(private val robotsList: MutableList<Robot>) : RecyclerView.Adapter<RobotAdapter.RobotViewHolder>() {
    class RobotViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val robotImage: ImageView
        val robotName: TextView
        val robotEmail: TextView

        init {
            robotImage = view.findViewById(R.id.robot_image)
            robotName = view.findViewById(R.id.robot_name)
            robotEmail = view.findViewById(R.id.robot_email)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RobotViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.robot_item, parent, false)
        return RobotViewHolder(view)
    }

    override fun onBindViewHolder(holder: RobotViewHolder, position: Int) {
        val robotId = robotsList[position].id
        val robotName = robotsList[position].name
        val robotEmail = robotsList[position].email
        val robotImage = robotsList[position].url
        Glide.with(holder.itemView)
            .load(robotImage)
            .centerCrop()
            .into(holder.robotImage)

        holder.robotName.text = "Name: $robotName"
        holder.robotEmail.text = "Email: $robotEmail"
    }

    override fun getItemCount(): Int {
        return robotsList.size;
    }
}